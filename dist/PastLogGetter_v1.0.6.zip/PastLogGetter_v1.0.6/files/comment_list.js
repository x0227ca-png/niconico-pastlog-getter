let allComments = [];
let ownerComments = [];
let currentSort = { key: 'time', order: 'asc' };

function getActiveComments() {
    const type = document.getElementById('comment-type').value;
    if (type === 'viewer') return allComments;
    if (type === 'owner') return ownerComments;
    return [...allComments, ...ownerComments].sort((a, b) => (a.vposMs || 0) - (b.vposMs || 0));
}

function formatTime(vposMs) {
    const totalSeconds = Math.floor(vposMs / 1000);
    const min = Math.floor(totalSeconds / 60);
    const sec = totalSeconds % 60;
    return `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

function renderComments(data) {
    const tbody = document.getElementById('comment-tbody');
    const noResults = document.getElementById('no-results');
    tbody.innerHTML = '';

    if (data.length === 0) {
        noResults.style.display = 'block';
        return;
    }
    noResults.style.display = 'none';

    data.forEach(comment => {
        const tr = document.createElement('tr');
        const nicoruOpacity = Math.min((comment.nicoruCount || 0) / 100, 1);
        tr.style.setProperty('--nicoru-opacity', nicoruOpacity);
        tr.className = 'nicoru-bg' + (comment.isOwner ? ' owner-comment' : '');
        const commands = (comment.commands || []).join(' ');
        const commentText = escapeHtml(comment.body);
        const commentTextCollapsed = commentText.replace(/<br>/g, ' ');
        const hasLineBreak = comment.body.includes('\n');
        tr.innerHTML = `
            <td class="time-cell">${formatTime(comment.vposMs)}</td>
            <td class="type-cell">${comment.isOwner ? '投稿者' : ''}</td>
            <td class="userid-cell">${comment.userId || ''}</td>
            <td class="score-cell">${comment.score || 0}</td>
            <td class="command-cell" title="${escapeHtml(commands)}">${escapeHtml(commands)}</td>
            <td class="comment-cell collapsed" title="クリックで展開">${commentTextCollapsed}</td>
            <td class="nicoru-cell">${comment.nicoruCount || 0}</td>
        `;
        if (hasLineBreak) {
            tr.querySelector('.comment-cell').addEventListener('click', function() {
                const isCollapsed = this.classList.toggle('collapsed');
                this.innerHTML = isCollapsed ? commentTextCollapsed : commentText;
                this.title = isCollapsed ? 'クリックで展開' : 'クリックで折りたたむ';
            });
        }
        tbody.appendChild(tr);
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML.replace(/\n/g, '<br>');
}

function sortComments(key, order, data) {
    const sorted = [...data];
    sorted.sort((a, b) => {
        let valA, valB;
        switch (key) {
            case 'time':
                valA = a.vposMs;
                valB = b.vposMs;
                break;
            case 'type':
                valA = a.isOwner ? 1 : 0;
                valB = b.isOwner ? 1 : 0;
                break;
            case 'userId':
                valA = a.userId || '';
                valB = b.userId || '';
                return order === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
            case 'score':
                valA = a.score || 0;
                valB = b.score || 0;
                break;
            case 'command':
                valA = (a.commands || []).join(' ');
                valB = (b.commands || []).join(' ');
                return order === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
            case 'comment':
                valA = a.body || '';
                valB = b.body || '';
                return order === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
            case 'nicoru':
                valA = a.nicoruCount || 0;
                valB = b.nicoruCount || 0;
                break;
            default:
                return 0;
        }
        return order === 'asc' ? valA - valB : valB - valA;
    });
    return sorted;
}

function updateTable() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    const comments = getActiveComments();
    let filtered = comments;

    if (searchTerm) {
        filtered = comments.filter(c =>
            (c.body || '').toLowerCase().includes(searchTerm)
        );
    }

    const sorted = sortComments(currentSort.key, currentSort.order, filtered);
    renderComments(sorted);

    document.getElementById('total-count').textContent = `${filtered.length}件`;
}

document.querySelectorAll('th[data-sort]').forEach(th => {
    th.addEventListener('click', () => {
        const key = th.dataset.sort;
        if (currentSort.key === key) {
            currentSort.order = currentSort.order === 'asc' ? 'desc' : 'asc';
        } else {
            currentSort.key = key;
            currentSort.order = 'asc';
        }

        document.querySelectorAll('th').forEach(t => {
            t.classList.remove('sorted-asc', 'sorted-desc');
        });
        th.classList.add(currentSort.order === 'asc' ? 'sorted-asc' : 'sorted-desc');

        updateTable();
    });
});

document.getElementById('search-input').addEventListener('input', updateTable);
document.getElementById('comment-type').addEventListener('change', updateTable);

chrome.storage.local.get('commentListData', (result) => {
    if (result.commentListData) {
        allComments = (result.commentListData.comments || []).map(c => ({ ...c, isOwner: false }));
        ownerComments = (result.commentListData.ownerComments || []).map(c => ({ ...c, isOwner: true }));
        document.getElementById('video-title').textContent = result.commentListData.videoTitle || '';
        updateTable();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const table = document.querySelector('table');
    const ths = table.querySelectorAll('th');
    let resizing = null;
    let startX = 0;
    let startWidth = 0;

    ths.forEach((th) => {
        const handle = document.createElement('span');
        handle.className = 'resize-handle';
        th.appendChild(handle);

        handle.addEventListener('mousedown', function(e) {
            resizing = th;
            startX = e.clientX;
            startWidth = th.offsetWidth;
            th.classList.add('resizing');
            document.body.style.cursor = 'col-resize';
            e.preventDefault();
            e.stopPropagation();
        });
    });

    document.addEventListener('mousemove', function(e) {
        if (!resizing) return;
        const diff = e.clientX - startX;
        const newWidth = Math.max(30, startWidth + diff);
        resizing.style.width = newWidth + 'px';
        resizing.style.minWidth = newWidth + 'px';
        resizing.style.maxWidth = newWidth + 'px';
    });

    document.addEventListener('mouseup', function() {
        if (resizing) {
            resizing.classList.remove('resizing');
            resizing = null;
            document.body.style.cursor = '';
        }
    });
});
