let kakoLogCanvasElement,
  SuperDanmakuCanvasElement,
  videoElement,
  CommentLoadingScreen,
  CustomVideoContainer,
  PlayerContainer,
  CommentLoadingScreenWrapper,
  loading,
  loading_text,
  link,
  OLD_DATE,
  OLD_TIME,
  DRAW_,
  apiData;
let COMMENT = [];

// 2026年対応: サイト側CSSクラスへの依存をなくし、ボタンだけは独立して表示する。
let pastLogSettingHTML = null;
let pastLogSettingLoadError = null;
let pastLogPrepared = false;
let pastLogPrepareAttempted = false;
let pastLogPrepareError = null;
let pastLogBootstrapTimer = null;
let pastLogLastVideoAnchor = null;

function isWatchPage() {
  return /^\/watch\/(?:sm|so|nm)\d+/.test(location.pathname);
}

function getVideoAnchor() {
  return document.querySelector('[data-name="video-content"]') || document.querySelector('video');
}

function getPlaybackVideo() {
  const anchor = getVideoAnchor();
  if (anchor && anchor.tagName === "VIDEO") return anchor;
  return (anchor && anchor.querySelector('video')) || document.querySelector('video');
}

// コメントリストの「すべてのコメント」の右側に設置する。
// プレーヤー内に浮かせる方式は使用しない。
function findCommentsControl() {
  const controls = document.querySelectorAll('button, [role="button"]');
  for (const control of controls) {
    if (control.closest('#allcommentsetting') || control.closest('#AllCommentViewButton')) continue;
    const label = `${control.textContent || ""} ${control.getAttribute('aria-label') || ""}`.replace(/\s/g, '');
    if (label.includes('すべてのコメント') && control.getClientRects().length) return control;
  }
  return null;
}

function findCommentsHeader() {
  // フィルターが表示されるまでは、コメント欄の見出しに配置する。
  const candidates = document.querySelectorAll('h2, h3, button, [role="heading"]');
  for (const item of candidates) {
    if (item.closest('#allcommentsetting')) continue;
    if ((item.textContent || '').trim() === 'コメントリスト' && item.getClientRects().length) return item;
  }
  return null;
}

function placePastLogButton() {
  const button = document.getElementById('AllCommentViewButton');
  if (!button) return;
  if (!isWatchPage()) {
    button.style.display = 'none';
    return;
  }
  const anchor = findCommentsControl() || findCommentsHeader();
  if (!anchor || !anchor.parentElement) {
    button.style.display = 'none';
    return;
  }
  if (anchor.nextElementSibling !== button) anchor.insertAdjacentElement('afterend', button);
  button.style.display = 'inline-flex';
}

function ensurePastLogButton() {
  if (!document.body || !isWatchPage()) return;
  let button = document.getElementById('AllCommentViewButton');
  if (!button) {
    button = document.createElement('button');
    button.id = 'AllCommentViewButton';
    button.type = 'button';
    button.textContent = '過去ログ';
    button.title = '過去ログ取得の設定を開く';
    button.setAttribute('aria-label', '過去ログ取得');
    button.style.cssText = [
      'display:none', 'position:static', 'z-index:2', 'flex-shrink:0',
      'align-items:center', 'justify-content:center', 'vertical-align:middle',
      'margin-left:8px', 'min-width:70px', 'height:30px', 'padding:0 10px',
      'border:1px solid #79a2c5', 'border-radius:16px',
      'background:linear-gradient(149deg,#f0f2ff,#bfeaff)',
      'color:#003b7b', 'font-size:12px', 'font-weight:bold',
      'cursor:pointer', 'pointer-events:auto'
    ].join(';');
    button.addEventListener('click', togglePastLogPanel);
    document.body.appendChild(button);
  }
  placePastLogButton();
}

function togglePastLogPanel() {
  if (!pastLogPrepared) tryPreparePastLog();
  if (pastLogPrepareError) {
    alert(`【過去ログ取得】設定画面の初期化に失敗しました。\n${pastLogPrepareError.message}\n\n開発者ツールのコンソールも確認してください。`);
    return;
  }
  const panel = document.getElementById("allcommentsetting");
  if (panel) {
    const isHidden = getComputedStyle(panel).display === "none";
    panel.style.setProperty("display", isHidden ? "block" : "none", "important");
    panel.style.visibility = "visible";
    return;
  }
  const message = pastLogSettingLoadError
    ? `設定ファイルを読み込めません: ${pastLogSettingLoadError.message}\n\n元の拡張機能フォルダに files/setting.html があるか確認してください。`
    : pastLogPrepareError
      ? `設定画面の初期化に失敗しました: ${pastLogPrepareError.message}\n\nChromeの開発者ツールでエラーを確認してください。`
      : "動画プレーヤーまたは設定画面の読み込み中です。少し後にもう一度押してください。";
  alert(`【過去ログ取得】\n${message}`);
}

function ensureCanvasOnCurrentPlayer() {
  if (!CustomVideoContainer) return;
  const anchor = getVideoAnchor();
  if (!anchor || !anchor.parentElement) return;
  if (CustomVideoContainer.previousElementSibling !== anchor) {
    anchor.after(CustomVideoContainer);
    const parent = CustomVideoContainer.parentElement;
    if (parent && getComputedStyle(parent).position === "static") {
      parent.style.position = "relative";
    }
  }
  videoElement = getPlaybackVideo();
}

function tryPreparePastLog() {
  ensurePastLogButton();
  if (pastLogPrepared || pastLogPrepareAttempted || !pastLogSettingHTML || !getVideoAnchor()) return;
  pastLogPrepareAttempted = true;
  // 必要な設定HTMLが存在しない場合は、ボタンだけ表示して警告できるようにする。
  try {
    PREPARE();
    pastLogPrepared = true;
    pastLogPrepareError = null;
  } catch (error) {
    pastLogPrepareError = error;
    console.error("[過去ログ取得] 初期化失敗:", error);
  }
}

function schedulePastLogBootstrap() {
  if (pastLogBootstrapTimer !== null) return;
  pastLogBootstrapTimer = setTimeout(() => {
    pastLogBootstrapTimer = null;
    ensurePastLogButton();
    if (pastLogPrepared) {
      ensureCanvasOnCurrentPlayer();
    } else {
      tryPreparePastLog();
    }
  }, 120);
}


// 2026年対応: watch/{id}?responseType=json が HTTP 400 を返す環境でも
// ページHTML内の server-response / レガシーdata-api-data / watch v3 APIを順番に試す。
function parseVideoInfoFromDOM(root, videoId) {
  const sources = [
    root.querySelector('meta[name="server-response"]')?.getAttribute('content'),
    root.querySelector('#js-initial-watch-data')?.getAttribute('data-api-data')
  ];
  for (const content of sources) {
    if (!content) continue;
    try {
      const obj = JSON.parse(content);
      const data = obj?.data?.response || obj?.response || obj?.data || obj;
      if (data?.comment?.nvComment && data?.video &&
          (!data.video.id || data.video.id === videoId)) {
        return data;
      }
    } catch (error) {
      console.warn('[過去ログ取得] ページ内の動画情報を読み取れません:', error);
    }
  }
  return null;
}

async function loadVideoInfo(videoId) {
  // 動画ページで meta が残っている場合は追加通信しない。
  const embedded = parseVideoInfoFromDOM(document, videoId);
  if (embedded) {
    logger('視聴ページの埋め込み動画情報を利用します');
    return embedded;
  }

  const failures = [];
  try {
    // ニコニコ側が描画時にmetaを削除する場合があるため、HTMLを再取得する。
    const response = await fetch(`${location.origin}/watch/${encodeURIComponent(videoId)}`, {
      credentials: 'include', cache: 'no-store'
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const data = parseVideoInfoFromDOM(doc, videoId);
    if (data) {
      logger('視聴ページHTMLから動画情報を取得しました');
      return data;
    }
    throw new Error('HTML内にcomment.nvCommentが見つかりません');
  } catch (error) {
    failures.push(`視聴ページ: ${error.message}`);
    console.warn('[過去ログ取得] 視聴ページHTMLからの取得失敗:', error);
  }

  // 最後にニコニコのwatch v3 APIを試す（ログイン済ブラウザを想定）。
  try {
    const trackId = `${Math.random().toString(36).slice(2).padEnd(10,'0').slice(0,10)}_${Date.now()}`;
    const url = `${location.origin}/api/watch/v3/${encodeURIComponent(videoId)}?actionTrackId=${trackId}&noSideEffect=true`;
    const response = await fetch(url, {
      credentials: 'include',
      headers: { 'X-Frontend-Id': '6', 'X-Frontend-Version': '0' }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const obj = await response.json();
    const data = obj?.data?.response || obj?.data;
    if (!data?.comment?.nvComment) {
      throw new Error(`コメント取得情報なし: ${obj?.meta?.errorCode || '詳細不明'}`);
    }
    logger('watch v3 APIから動画情報を取得しました');
    return data;
  } catch (error) {
    failures.push(`watch v3: ${error.message}`);
    console.warn('[過去ログ取得] watch v3からの取得失敗:', error);
  }
  throw new Error('動画情報を取得できませんでした。\n' + failures.join('\n'));
}

function calculateDesiredCommentCount(durationSeconds) {
  const minutes = durationSeconds / 60;

  let count1;
  if (minutes < 1) {
    count1 = 100;
  } else if (minutes < 5) {
    count1 = 250;
  } else if (minutes < 10) {
    count1 = 500;
  } else {
    count1 = 1000;
  }

  const count2 = Math.ceil(minutes) * 100;

  return Math.max(count1, count2);
}

async function LOADCOMMENT(mode) {
  ensureCanvasOnCurrentPlayer();
  if (!CustomVideoContainer || !document.getElementById("kakolog_comment")) {
    alert("【過去ログ取得】プレーヤー描画領域が見つかりません。動画ページを再読み込みしてください。");
    return;
  }

  try {
  logger("お待ち下さい");
  loading.style.display = "block";
  document.getElementsByClassName("loadbutton_text")[0].innerText =
    "読み込み中";

  let match = location.href.match(/\/watch\/(sm\d+)/);
  if (match === null) {
    match = location.href.match(/\/watch\/(so\d+)/);
  }
  if (match === null) {
    logger("動画ページではありません。");
    return;
  }

  logger("動画情報を取得しています…");
  apiData = await loadVideoInfo(match[1]);
  logger("動画情報の取得に成功しました");

  const adjustCommentCount = document.getElementById("adjust_comment_count").checked;
  let desiredCommentCount = 1000;
  if (adjustCommentCount) {
    const videoDuration = videoElement.duration;
    desiredCommentCount = calculateDesiredCommentCount(videoDuration);
    const durationMin = Math.floor(videoDuration / 60);
    const durationSec = Math.floor(videoDuration % 60);
    logger(
      `動画時間: ${durationMin}分${durationSec}秒 - 取得件数目安: ${desiredCommentCount}件`
    );
  }

  //コメント取得
  const nvComment = apiData.comment.nvComment;
  const threadNames = nvComment.params.targets.map(t => {
    if (t.fork === "owner") return "投稿者";
    if (t.fork === "easy") return "エンジェル";
    return "一　般";
  });
  logger(
    `${threadNames.join("・")}スレッドを読み込みます。`
  );

  const date =
    OLD_DATE.value === ""
      ? new Date(apiData.video.registeredAt)
      : new Date(OLD_DATE.value + " " + OLD_TIME.value);
  const ownerComments = [];
  const comments = [];
  let isLoggedIn = true;
  let threadKey = nvComment.threadKey;
  for (const i in nvComment.params.targets) {
    const thread = nvComment.params.targets[i];
    if (
      document.getElementById("iseasy").checked &&
      thread.fork == "easy"
    ) {
      continue;
    }
    let baseData = {
      threadKey: threadKey,
      params: {
        language: nvComment.params.language,
        targets: [thread],
      },
    };
    let lastTime = Math.floor(date.getTime() / 1000);
    if (isLoggedIn) {
      const req = await fetch(`${nvComment.server}/v1/threads`, {
        method: "POST",
        headers: {
          "content-type": "text/plain;charset=UTF-8",
          "x-client-os-type": "others",
          "x-frontend-id": "6",
          "x-frontend-version": "0",
        },
        body: JSON.stringify({
          ...baseData,
          additionals: {
            res_from: -1000,
            when: lastTime,
          },
        }),
      });
      const res = await req.json();
      if (res?.meta?.errorCode === "TOO_MANY_REQUESTS") {
        logger(
          `API呼び出しの回数制限を超えました。しばらくお待ち下さい。`
        );
        await sleep(60000);
      } else if (res?.meta?.errorCode === "EXPIRED_TOKEN") {
        logger(`threadKeyを新たに取得しています…`);
        await fetch(
          "https://nvapi.nicovideo.jp/v1/comment/keys/thread?videoId=" +
            apiData.video.id,
          {
            headers: {
              "X-Frontend-Id": "6",
              "X-Frontend-Version": "0",
              "Content-Type": "application/json",
            },
            credentials: "include",
          }
        )
          .then((r) => r.json())
          .then((j) => {
            threadKey = j.data.threadKey;
            baseData.threadKey = j.data.threadKey;
          });
      } else if (res?.meta?.errorCode === "INVALID_TOKEN") {
        logger("ログインしていません。");
        alert(
          "【過去ログ取得】ログアウト状態です。ログインをして再度実行してください。"
        );
        document.getElementById("loading").style.display = "none";
        document.getElementById("allcommentsetting").style.display = "none";
        isLoggedIn = false;
      } else {
        let fetchedComments = res.data.threads[0].comments;
        (thread.fork === "owner" ? ownerComments : comments).push(
          ...fetchedComments
        );
        const threadLabel = thread.fork === "owner" ? "投稿者" : "一　般";
        logger(
          `${threadLabel}：${fetchedComments.length}件のコメントを取得しました`
        );

        const targetComments = thread.fork === "owner" ? ownerComments : comments;
        while (targetComments.length < desiredCommentCount && fetchedComments.length === 1000) {
          lastTime = Math.floor(new Date(fetchedComments[0].postedAt).getTime() / 1000);

          logger(`追加取得中... (${targetComments.length}/${desiredCommentCount}件)`);
          await sleep(1000);

          const nextReq = await fetch(`${nvComment.server}/v1/threads`, {
            method: "POST",
            headers: {
              "content-type": "text/plain;charset=UTF-8",
              "x-client-os-type": "others",
              "x-frontend-id": "6",
              "x-frontend-version": "0",
            },
            body: JSON.stringify({
              ...baseData,
              additionals: {
                res_from: -1000,
                when: lastTime,
              },
            }),
          });
          const nextRes = await nextReq.json();

          if (nextRes?.meta?.errorCode) {
            logger(`追加取得でエラーが発生しました: ${nextRes.meta.errorCode}`);
            break;
          }

          fetchedComments = nextRes.data.threads[0].comments;
          targetComments.push(...fetchedComments);
          logger(
            `${threadLabel}：${fetchedComments.length}件のコメントを追加取得しました`
          );
        }
      }
    }
    if (!isLoggedIn) break;
  }
  CommentLoadingScreenWrapper.style.background = `rgba(0, 0, 0, .9)`;
  logger(comments.length + "件のコメントを読み込みました");
  logger(`NG設定を適用しています`);

  COMMENT = [
    {
      commentCount: comments.length,
      comments: await COMMENT_CONTROL(comments),
      fork: "comment-kakolog",
      id: 0,
    },
    {
      commentCount: ownerComments.length,
      comments: ownerComments, //投稿者コメントにフィルターを適用する?
      fork: "owner",
      id: 1,
    },
  ];
  document.getElementById("reload_niconicomments").onclick = async () => {
    await LOADCOMMENT();
  };

  logger(`描画準備中`);
  document.getElementById("progress_left").style.width = "0%";
  PLAYCOMMENT();
  } catch (error) {
    console.error('[過去ログ取得] 過去ログ取得失敗:', error);
    if (loading) loading.style.display = 'none';
    const startText = document.querySelector('.loadbutton_text');
    if (startText) startText.innerText = '読み込み開始！';
    const startButton = document.getElementById('zenkomebutton');
    if (startButton) startButton.classList.remove('disabled');
    try { logger('取得失敗: ' + error.message); } catch (_) { /* 表示領域が無い場合 */ }
    alert('【過去ログ取得】取得に失敗しました。\n' + error.message + '\n\nNetwork / Consoleで詳細を確認してください。');
  }

}

let niconiComments, comment_list_active;
let observer = new MutationObserver(function () {
  if (href.split("?")[0] !== location.href.split("?")[0]) {
    const loaded = document.getElementById("loaded");
    const wrapperButtons = document.getElementById("wrapper_buttons");
    const wrapperButtons2 = document.getElementById("wrapper_buttons2");
    const scroll = document.getElementsByClassName("scroll")[0];
    const commentRenderer = document.getElementsByClassName("CommentRenderer")[0];

    if (loaded) loaded.style.zIndex = "0";
    if (wrapperButtons) {
      wrapperButtons.style.height = "0px";
      wrapperButtons.style.opacity = "0";
    }
    if (wrapperButtons2) {
      wrapperButtons2.style.height = "0px";
      wrapperButtons2.style.opacity = "0";
    }
    if (scroll) scroll.style.height = "calc(100% - 71px)";
    DRAW_ = false;
    if (commentRenderer) commentRenderer.style.display = "block";
    if (CustomVideoContainer) CustomVideoContainer.style.display = "none";
    if (link) link.style.visibility = "hidden";
    if (loaded) loaded.style.visibility = "hidden";
    const zenkomebutton = document.getElementById("zenkomebutton");
    if (zenkomebutton) zenkomebutton.classList.remove("disabled");
    const reloadBtn = document.getElementById("reload_niconicomments");
    if (reloadBtn) reloadBtn.disabled = true;
    const loadbuttonText = document.getElementsByClassName("loadbutton_text")[0];
    if (loadbuttonText) loadbuttonText.innerText = "読み込み開始！";
    const progressLeft = document.getElementById("progress_left");
    if (progressLeft) progressLeft.style.width = "100%";
    href = location.href;
    COMMENT = [];
    schedulePastLogBootstrap();
  }
});
let href = location.href;
observer.observe(document, { childList: true, subtree: true });

function load_NiconiComments() {
  let commentLimitOption = undefined;
  if (document.getElementById("use_comment_limit").checked) {
    commentLimitOption = Number(document.getElementById("comment_limit_num").value) || undefined;
  }
  niconiComments = new NiconiComments(kakoLogCanvasElement, COMMENT, {
    scale: document.getElementById("bar_textsize").value * 0.01,
    keepCA: document.getElementById("checkbox4").checked,
    commentLimit: commentLimitOption,
    config: {
      contextStrokeOpacity: Number(document.getElementById("bar_stroke").value),
      contextLineWidth: 3.5,
    },
    format: "v1",
  });
}
function PLAYCOMMENT() {
  ensureCanvasOnCurrentPlayer();
  if (!CustomVideoContainer) return;
  CustomVideoContainer.style.display = "block";
  kakoLogCanvasElement = document.getElementById("kakolog_comment");

  async function setup() {
    videoElement = getPlaybackVideo();
    if (!videoElement) {
      logger("動画要素が見つかりません。ページを再読み込みしてください。");
      return;
    }

    kakoLogCanvasElement.style.opacity =
      document.getElementById("bar_alpha").value * 0.01;

    load_NiconiComments();
    document.getElementById("reload_niconicomments").disabled = false;

    loading.style.display = "none";
    CustomVideoContainer.style.display = "block";

    DRAW_ = true;
    function draw() {
      niconiComments.drawCanvas(Math.floor(videoElement.currentTime * 100));
      if (DRAW_ == false) return;

      setTimeout(draw, 1000 / document.getElementById("bar_fps").value);
    }
    draw();

    const originalCommentOverlay = document.querySelector('[data-name="comment"]');
    if (originalCommentOverlay) originalCommentOverlay.style.display = "none";

    setTimeout(() => {
      document.getElementById("wrapper_buttons").style.height = "30px";
      document.getElementById("wrapper_buttons").style.opacity = "1";
      document.getElementById("wrapper_buttons2").style.height = "30px";
      document.getElementById("wrapper_buttons2").style.opacity = "1";
      document.getElementsByClassName("scroll")[0].style.height =
        "calc(100% - 151px)";
    }, 200);
  }
  document.getElementById("loaded").style.zIndex = "2";
  const comment_list = document.getElementById("comment_list");
  document
    .getElementById("comment_list_open")
    .addEventListener("click", function () {
      comment_list.style.visibility = "visible";
      comment_list_active = true;
      auto_scroll = true;
      document.getElementById("auto_scroll").checked = true;
      let passIndex = COMMENT[0].comments.findIndex(function (element) {
        return element.vposMs > Math.floor(videoElement.currentTime * 1000);
      });
      if (commentElements[passIndex]) {
        commentElements[passIndex].scrollIntoView({ block: "center" });
      }
    });
  document
    .getElementById("comment_list_exit")
    .addEventListener("click", function () {
      comment_list.style.visibility = "hidden";
      comment_list_active = false;
    });
  document
    .getElementById("open_comment_all")
    .addEventListener("click", function () {
      chrome.storage.local.set({
        commentListData: {
          comments: COMMENT[0].comments,
          ownerComments: COMMENT[1].comments,
          videoTitle: apiData.video.title
        }
      }, () => {
        let commentListHtml = chrome.runtime.getURL("files/comment_list.html");
        window.open(commentListHtml, "_blank");
      });
    });
  LIST_COMMENT();
  let Comment_Show_Button = document.querySelector(
    "[aria-label='コメントを非表示にする']"
  );
  if (Comment_Show_Button == undefined) {
    Comment_Show_Button = document.querySelector(
      "[aria-label='コメントを表示する']"
    );
  }
  let Comment_SH = new MutationObserver(function () {
    CustomVideoContainer.style.zIndex =
      Comment_Show_Button.getAttribute("aria-label") == "コメントを表示する"
        ? 0
        : 1;
  });
  if (Comment_Show_Button) {
    Comment_SH.observe(Comment_Show_Button, { attributes: true, attributeFilter: ["aria-label"] });
  }
  kakoLogCanvasElement.style.display = "block";

  setTimeout(setup, 1000);
}
let list_interval;
let auto_scroll = true;
let commentElements = [];
let allCommentsData = [];
function fixPastLogCommentListHeaderColor() {
  const positionText = document.getElementById("now_comment_pos");
  if (positionText) positionText.style.setProperty("color", "#161616", "important");

  const autoScrollCheckbox = document.getElementById("auto_scroll");
  if (autoScrollCheckbox) {
    // input の横にテキストノードが直接置かれている構造にも対応。
    const wrapper = autoScrollCheckbox.parentElement;
    if (wrapper && wrapper.closest("#comment_list")) {
      wrapper.style.setProperty("color", "#161616", "important");
    }
    const label = document.querySelector('label[for="auto_scroll"]');
    if (label && label.closest("#comment_list")) {
      label.style.setProperty("color", "#161616", "important");
    }
  }
}

function LIST_COMMENT() {
  fixPastLogCommentListHeaderColor();
  allCommentsData = [...COMMENT[0].comments, ...COMMENT[1].comments].sort(function (a, b) {
    if (a.vposMs < b.vposMs) return -1;
    if (a.vposMs > b.vposMs) return 1;
    return 0;
  });

  let now_comment_pos = document.getElementById("now_comment_pos");
  let commentListBottom = document.getElementById("bottom");
  let commentListComments = document.getElementById("comment_list_comments");

  commentListComments.innerHTML = "";
  commentElements = [];
  for (let i = 0; i < allCommentsData.length; i++) {
    let comment = allCommentsData[i];
    let isOwner = COMMENT[1].comments.includes(comment);
    let commentElement = document.createElement("div");
    commentElement.className = "list_comment";
    commentElement.dataset.vpos = comment.vposMs;
    let time = Math.floor(comment.vposMs / 1000);
    let min = Math.floor(time / 60);
    let sec = time % 60;
    let timeStr = `${String(min).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
    let bgColor = isOwner ? 'rgba(102, 126, 234, 0.15)' : `rgba(243, 186, 0, ${(comment.nicoruCount || 0) / 10})`;
    let commentBody = comment.body.replace(/\n/g, ' ');
    commentElement.innerHTML = `<div style="padding:0px 2px;display:flex;background-color:${bgColor};color:#111;"><button class="comment_seek_btn" style="width:50px;flex-shrink:0;text-align:center;font-size:11px;color:#1a0dab;background:none;border:none;cursor:pointer;padding:0;text-decoration:underline;">${timeStr}</button><p style="width:30px;flex-shrink:0;text-align:center;font-size:10px;color:#667eea;font-weight:600;">${isOwner ? '投' : ''}</p><p style="width:40px;flex-shrink:0;text-align:right;font-size:11px;color:#444;">${comment.score || 0}</p><p style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#111;">${commentBody}</p><p style="width:40px;flex-shrink:0;text-align:right;color:#111;">${comment.nicoruCount || ""}</p></div>`;
    commentElement.querySelector(".comment_seek_btn").addEventListener("click", () => {
      videoElement.currentTime = comment.vposMs / 1000;
    });
    commentListComments.appendChild(commentElement);
    commentElements.push(commentElement);
  }

  commentListBottom.addEventListener("wheel", () => {
    auto_scroll = false;
    document.getElementById("auto_scroll").checked = false;
  });

  if (list_interval) clearInterval(list_interval);
  list_interval = setInterval(() => {
    if (!comment_list_active) return;

    let currentTimeMs = Math.floor(videoElement.currentTime * 1000);

    let passIndex = allCommentsData.findIndex(function (element) {
      return element.vposMs > currentTimeMs;
    });

    now_comment_pos.innerText = `現在のコメント位置${passIndex}/${commentElements.length}`;

    if (auto_scroll && passIndex > 0 && commentElements[passIndex - 1]) {
      let el = commentElements[passIndex - 1];
      let container = commentListBottom;
      let elTop = el.offsetTop;
      let elHeight = el.offsetHeight;
      let containerHeight = container.clientHeight;
      let targetScroll = elTop - containerHeight + elHeight + 30;
      container.scrollTo({ top: targetScroll, behavior: 'smooth' });
    }
  }, 200);
}

const logger = (msg, load) => {
  const p = document.createElement("p");
  p.innerText = msg;
  if (load != false) {
    loading_text.innerText = msg;
  }

  CommentLoadingScreen.appendChild(p);
  CommentLoadingScreenWrapper.scrollBy(0, CommentLoadingScreen.clientHeight);
};

const sleep = (time) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve();
    }, time);
  });
};

let NG_LIST_COMMAND = [];
let NG_LIST_COMMENT = [];
const COMMENT_CONTROL = (comments) => {
  return new Promise((resolve) => {
    let ng_score = document.getElementById("ng_score").value;
    let nicoru_limit = document.getElementById("nicoru_num");
    let premium_filter = document.getElementById("premium_filter");
    let comment_art_filter = document.getElementById("comment_art_filter");
    let cmd_mincho = document.getElementById("cmd_mincho");
    let cmd_gothic = document.getElementById("cmd_gothic");

    for (const i in comments) {
      const comment = comments[i];
      if (comment.commands === undefined) {
        comment.commands = [];
      } else {
        comment.commands = comment.commands.map((value) => value.toLowerCase());
      }
    }

    const addCommands = [];
    if (cmd_mincho && cmd_mincho.checked) addCommands.push("mincho");
    if (cmd_gothic && cmd_gothic.checked) addCommands.push("gothic");
    if (addCommands.length > 0) {
      comments.forEach(comment => {
        addCommands.forEach(cmd => {
          if (!comment.commands.includes(cmd)) {
            comment.commands.push(cmd);
          }
        });
      });
    }

    let commentArtUserIds = new Set();
    if (comment_art_filter.checked) {
      const blockChars = "▏▎▍▌▋▊▉▁▂▃▄▅▆▇█";
      comments.forEach((comment) => {
        const hasNewline = comment.body.includes("\n");
        const artCommands = ["ca", "full", "patissier"];
        const hasArtCommand = comment.commands.some((cmd) => artCommands.includes(cmd));
        const hasBlockChar = [...comment.body].some(char => blockChars.includes(char));
        if (hasNewline || hasArtCommand || hasBlockChar) {
          commentArtUserIds.add(comment.userId);
        }
      });
    }

    NG_LIST_COMMAND.forEach((NG) => {
      let commands = NG.toLowerCase().split(" ");
      comments = comments.filter((comment) => {
        let ng_point = commands.length;
        commands.forEach((command) => {
          if (comment.commands.includes(command)) {
            ng_point -= 1;
          }
        });
        return ng_point > 0;
      });
    });
    NG_LIST_COMMENT.forEach(
      (NG) =>
        (comments = comments.filter(
          (comment) => comment.body.includes(NG) === false
        ))
    );
    comments = comments.filter((comment) => comment.score >= ng_score);
    comments = comments.filter(
      (comment) => comment.nicoruCount >= nicoru_limit.value
    );
    if (premium_filter.checked) {
      comments = comments.filter((comment) => comment.isPremium === true);
    }
    if (comment_art_filter.checked) {
      comments = comments.filter((comment) => commentArtUserIds.has(comment.userId));
    }

    logger(comments.length + "件に減りました");
    resolve(comments);
  });
};

function PREPARE(observe) {
  // 元のサイドバーclassが存在しなくても、bodyへ設定画面を挿入できる。
  const sidebar = document.querySelector('[class~="grid-area_[sidebar]"]') ||
    document.querySelector('[data-name="sidebar"]');
  const settingHost = sidebar || document.body;
  if (!document.getElementById("allcommentsetting")) {
    settingHost.insertAdjacentHTML("afterbegin", pastLogSettingHTML);
  }
  let customStyle = document.getElementById("kakolog-compat-style");
  if (!customStyle) {
    customStyle = document.createElement("style");
    customStyle.id = "kakolog-compat-style";
    customStyle.textContent = `.CustomVideoContainer{width:100%;height:100%;position:absolute;top:0;left:0;pointer-events:none;}
      .CustomVideoContainer .CommentRenderer,.CustomVideoContainer canvas{width:100%;height:100%;}
      #allcommentsetting.kakolog-body-panel{position:fixed !important;top:66px !important;right:16px !important;left:auto !important;bottom:auto !important;width:min(420px,calc(100vw - 32px)) !important;max-height:calc(100vh - 82px) !important;overflow:auto !important;z-index:2147483646 !important;background:#fff;color:#222;border:1px solid #b4b4b4;border-radius:10px;box-shadow:0 8px 26px rgba(0,0,0,.35);}
      /* コメントリスト上部: 白背景での白文字を防ぐ。動画上のコメント描画は変更しない */
      #comment_list{color:#161616 !important;}
      #comment_list #now_comment_pos,
      #comment_list label:has(#auto_scroll),
      #comment_list label:has(#auto_scroll) span,
      #comment_list label[for="auto_scroll"],
      #comment_list label[for="auto_scroll"] span,
      #comment_list #auto_scroll + span,
      #comment_list #auto_scroll + label,
      #comment_list #auto_scroll ~ span {color:#161616 !important;}`;
    document.body.appendChild(customStyle);
  }
  const panel = document.getElementById("allcommentsetting");
  if (!panel) throw new Error("files/setting.html に allcommentsetting がありません");
  if (!sidebar) panel.classList.add("kakolog-body-panel");
  PlayerContainer = document.querySelector('[data-name="content"]') || getVideoAnchor()?.parentElement;
  CustomVideoContainer = document.querySelector(".CustomVideoContainer") || document.createElement("div");
  CustomVideoContainer.innerHTML = `<div class="CommentRenderer"><canvas id="kakolog_comment" width="1920" height="1080"></canvas><canvas id="SuperDanmakuCanvasElement" width="640" height="360"></canvas></div>`;
  CustomVideoContainer.classList.add("CustomVideoContainer", "InView");
  const logo = document.getElementById("logo");
  if (logo) logo.textContent = "過去ログ取得";
  const loadingImage = document.getElementById("loading_image");
  if (loadingImage) loadingImage.src = load_image;

  ensureCanvasOnCurrentPlayer();
  kakoLogCanvasElement = document.getElementById("kakolog_comment");
  SuperDanmakuCanvasElement = document.getElementById(
    "SuperDanmakuCanvasElement"
  );
  videoElement = getPlaybackVideo();

  SuperDanmakuCanvasElement.width = 640;
  SuperDanmakuCanvasElement.height = 360;

  CommentLoadingScreenWrapper = document.createElement("div");
  CommentLoadingScreenWrapper.id = "CommentLoadingScreenWrapper";
  CommentLoadingScreenWrapper.innerHTML =
    '<div id="CommentLoadingScreen"></div>';
  document
    .getElementsByClassName("CustomVideoContainer InView")[0]
    .appendChild(CommentLoadingScreenWrapper);

  CommentLoadingScreen = document.getElementById("CommentLoadingScreen");
  link = document.getElementById("loaded");
  CustomVideoContainer.style.display = "none";
  CustomVideoContainer.style.zIndex = "1";
  CustomVideoContainer.style.pointerEvents = "none";
  kakoLogCanvasElement.style = `position:absolute;top:0;left:0;width:100%;height:100%;z-index:0;display:block;object-fit:contain;`;
  SuperDanmakuCanvasElement.style =
    "position:absolute;top:0;left:0;width:100%;height:100%;z-index:1;display:block;opacity:0;";

  OLD_DATE = document.getElementById("zenkome-date");
  OLD_TIME = document.getElementById("zenkome-time");
  const setting = document.getElementById("allcommentsetting");

  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  OLD_DATE.value = `${year}-${month}-${day}`;
  OLD_TIME.value = `${hours}:${minutes}`;

  document.getElementsByClassName("ZenkomeCloseButton")[0].addEventListener(
    "click",
    () => {
      setting.style.display = "none";
    },
    false
  );
  OLD_DATE.min = "2007-03-03";
  OLD_DATE.max = new Date().getFullYear() + "-12-31";
  const val_stroke = document.getElementsByClassName("range_val");
  const bar_stroke = document.getElementsByClassName("range_bar");
  let get_kakolog_config = localStorage.getItem("kakolog_config");
  let kakolog_config;
  function CONFIG() {
    get_kakolog_config = localStorage.getItem("kakolog_config");
    if (get_kakolog_config == null || get_kakolog_config == "[null]") {
      localStorage.setItem(
        "kakolog_config",
        JSON.stringify({
          bar_textsize: 100,
          bar_stroke: 0.35,
          bar_alpha: 100,
          bar_fps: 30,
          keepCA: false,
          mode: "html5",
          ngscore: "-Infinity",
          nicoru_limit: 0,
          premium_filter: false,
          version: "1.0.0",
        })
      );
    } else {
      kakolog_config = JSON.parse(get_kakolog_config);
      document.getElementById("bar_textsize").value = kakolog_config.bar_textsize;
      document.getElementById("bar_stroke").value = kakolog_config.bar_stroke;
      document.getElementById("bar_alpha").value = kakolog_config.bar_alpha;
      document.getElementById("checkbox4").checked = kakolog_config.keepCA;
      document.getElementById("bar_fps").value = kakolog_config.bar_fps;
      document.getElementById("nicoru_num").value = kakolog_config.nicoru_limit || 0;
      document.getElementById("premium_filter").checked = kakolog_config.premium_filter || false;
      document.getElementById("ng_score").value = kakolog_config.ngscore || "-Infinity";
      for (let i = 0; i < val_stroke.length; i++) {
        val_stroke[i].innerText = bar_stroke[i].value;
      }
    }
  }

  let ng_storage = localStorage.getItem("ng_storage");
  let ngarray,
    SETTING_NG_LIST_COMMENT,
    SETTING_NG_LIST_COMMAND,
    SETTING_NG_LIST_ISEASY;

  function NG_DELETE(type, i) {
    ngarray[type].splice(i, 1);
    localStorage.setItem("ng_storage", JSON.stringify(ngarray));
    setTimeout(() => {
      ng_element();
    }, 100);
  }

  function ng_element() {
    ng_storage = localStorage.getItem("ng_storage");
    NG_LIST_COMMAND = [];
    NG_LIST_COMMENT = [];
    SETTING_NG_LIST_ISEASY = document.getElementById("iseasy");
    SETTING_NG_LIST_COMMENT = document.getElementById("ng_comment");
    SETTING_NG_LIST_COMMAND = document.getElementById("ng_command");
    loading_text = document.getElementById("loading_text");
    loading = document.getElementById("loading");
    SETTING_NG_LIST_COMMAND.innerHTML = "";
    SETTING_NG_LIST_COMMENT.innerHTML = "";

    if (ng_storage == null || ng_storage == "[null]") {
      localStorage.setItem(
        "ng_storage",
        JSON.stringify({ command: [], comment: [], easy: false })
      );
    } else {
      ngarray = JSON.parse(ng_storage);
      ngarray.command.forEach((command) => NG_LIST_COMMAND.push(command));
      ngarray.comment.forEach((comment) => NG_LIST_COMMENT.push(comment));

      SETTING_NG_LIST_COMMENT.innerHTML = "";
      SETTING_NG_LIST_COMMAND.innerHTML = "";
      for (let i = 0; i < NG_LIST_COMMENT.length; i++) {
        SETTING_NG_LIST_COMMENT.innerHTML += `<li>${NG_LIST_COMMENT[i]}
          <button id="del_e${i}" class="deletebutton" ></button></li>`;
      }
      for (let i = 0; i < NG_LIST_COMMENT.length; i++) {
        document.getElementById(`del_e${i}`).onclick = function (e) {
          NG_DELETE("comment", i);
        };
      }
      for (let i = 0; i < NG_LIST_COMMAND.length; i++) {
        SETTING_NG_LIST_COMMAND.innerHTML += `<li>${NG_LIST_COMMAND[i]}
          <button id="del_a${i}"  class="deletebutton" ></button></li>`;
      }
      for (let i = 0; i < NG_LIST_COMMAND.length; i++) {
        document.getElementById(`del_a${i}`).onclick = function (e) {
          NG_DELETE("command", i);
        };
      }
      SETTING_NG_LIST_ISEASY.checked = ngarray.easy;
    }
  }

  if (!observe) {
    ng_element();
    CONFIG();
  }
  document.getElementById("form_command").onclick = () => {
    ng_storage = localStorage.getItem("ng_storage");
    ngarray = JSON.parse(ng_storage);
    let ng_add = window.prompt("新たに追加するNGコマンドを入力してください。");
    if (ng_add === null || ng_add === "") return;
    ngarray.command.push(ng_add);
    localStorage.setItem("ng_storage", JSON.stringify(ngarray));

    setTimeout(() => {
      ng_element();
    }, 100);
  };
  document.getElementById("form_comment").onclick = () => {
    ng_storage = localStorage.getItem("ng_storage");
    ngarray = JSON.parse(ng_storage);
    let ng_add = window.prompt("新たに追加するNGコメントを入力してください。");
    if (ng_add === null || ng_add === "") return;
    ngarray.comment.push(ng_add);
    localStorage.setItem("ng_storage", JSON.stringify(ngarray));

    setTimeout(() => {
      ng_element();
    }, 100);
  };
  document.getElementById("iseasy").onclick = () => {
    ng_storage = localStorage.getItem("ng_storage");
    ngarray = JSON.parse(ng_storage);
    ngarray.easy = !ngarray.easy;
    localStorage.setItem("ng_storage", JSON.stringify(ngarray));
    setTimeout(() => {
      ng_element();
    }, 100);
  };
  document.getElementById("checkbox4").onclick = () => {
    get_kakolog_config = localStorage.getItem("kakolog_config");
    kakolog_config = JSON.parse(get_kakolog_config);
    kakolog_config.keepCA = !kakolog_config.keepCA;
    localStorage.setItem("kakolog_config", JSON.stringify(kakolog_config));
  };
  document.getElementById("nicoru_num").oninput = () => {
    get_kakolog_config = localStorage.getItem("kakolog_config");
    kakolog_config = JSON.parse(get_kakolog_config);
    kakolog_config.nicoru_limit = document.getElementById("nicoru_num").value;
    localStorage.setItem("kakolog_config", JSON.stringify(kakolog_config));
  };
  document.getElementById("ng_score").onchange = () => {
    get_kakolog_config = localStorage.getItem("kakolog_config");
    kakolog_config = JSON.parse(get_kakolog_config);
    kakolog_config.ngscore = document.getElementById("ng_score").value;
    localStorage.setItem("kakolog_config", JSON.stringify(kakolog_config));
  };
  document.getElementById("premium_filter").onclick = () => {
    get_kakolog_config = localStorage.getItem("kakolog_config");
    kakolog_config = JSON.parse(get_kakolog_config);
    kakolog_config.premium_filter = !kakolog_config.premium_filter;
    localStorage.setItem("kakolog_config", JSON.stringify(kakolog_config));
  };

  for (let i = 0; i < val_stroke.length; i++) {
    bar_stroke[i].addEventListener(
      "input",
      function (e) {
        val_stroke[i].innerText = e.target.value;
        if (this.id == "bar_alpha") {
          kakoLogCanvasElement.style.opacity = e.target.value * 0.01;
        }
        get_kakolog_config = localStorage.getItem("kakolog_config");
        kakolog_config = JSON.parse(get_kakolog_config);
        kakolog_config[bar_stroke[i].id] = e.target.value;
        localStorage.setItem("kakolog_config", JSON.stringify(kakolog_config));
      },
      false
    );
  }

  document.getElementById("islogger").addEventListener("change", function () {
    CommentLoadingScreenWrapper.style.display = this.checked ? "block" : "none";
  });

  document.getElementById("auto_scroll").addEventListener("change", function () {
    auto_scroll = this.checked;
    if (auto_scroll) {
      let passIndex = COMMENT[0].comments.findIndex(function (element) {
        return element.vposMs > Math.floor(videoElement.currentTime * 1000);
      });
      if (commentElements[passIndex]) {
        commentElements[passIndex].scrollIntoView({ block: "center" });
      }
    }
  });

  document.getElementById("use_comment_limit").addEventListener("change", function () {
    document.getElementById("comment_limit_num").disabled = !this.checked;
  });

  document.getElementById("zenkomebutton").onclick = () => {
    document.getElementById("zenkomebutton").classList.add("disabled");

    LOADCOMMENT();
  };

  // 旧実装は見つからない全画面ボタンをobserveして例外を出していた。
  // 全画面判定をDOM属性に依存させない。
  const updateFullscreenVisibility = () => {
    const panel = document.getElementById("allcommentsetting");
    if (!panel) return;
    if (document.fullscreenElement || document.body.classList.contains("is-fullscreen")) {
      panel.style.visibility = "hidden";
    } else {
      panel.style.visibility = "visible";
    }
    placePastLogButton();
  };
  document.addEventListener("fullscreenchange", updateFullscreenVisibility);
  ensurePastLogButton();

}

const index_html = chrome.runtime.getURL("files/setting.html");
const load_image = chrome.runtime.getURL("lib/load.svg");

// ボタンの表示は設定HTMLの取得に依存しない。
function startPastLogBootstrap() {
  ensurePastLogButton();
  fetch(index_html)
    .then((r) => {
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return r.text();
    })
    .then((html) => {
      pastLogSettingHTML = html;
      tryPreparePastLog();
    })
    .catch((error) => {
      pastLogSettingLoadError = error;
      console.error("[過去ログ取得] 設定HTML読み込み失敗:", error);
    });

  // SPAでの画面切り替え、および遅れて動画が生成される場合にも対応。
  const watchObserver = new MutationObserver(schedulePastLogBootstrap);
  watchObserver.observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("resize", schedulePastLogBootstrap);
  window.addEventListener("scroll", schedulePastLogBootstrap, true);
  document.addEventListener("fullscreenchange", schedulePastLogBootstrap);
  // DOMが変化しない動画や、ボタンが動画の上に重なる位置に移動した場合も追従。
  setInterval(() => {
    if (isWatchPage()) schedulePastLogBootstrap();
  }, 1500);
  schedulePastLogBootstrap();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startPastLogBootstrap, { once: true });
} else {
  startPastLogBootstrap();
}
